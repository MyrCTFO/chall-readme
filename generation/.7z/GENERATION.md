# How to generate this challenge
1. <++>
2. `<++>`
3. `generate.sh`

## How it was created
1. Code and README.txt was written by hand
2. [TTS](https://ttsmp3.com/) to generate sound for README.mp3 and mp4
3. Create word document, add flag part 4 in manually

4. Split flag into 5 parts:
 - [x] `MyrCTF{y`
 - [x] `ou_can_use`
 - [x] `_any_format_`
 - [x] `for_readmes_n`
 - [ ] `ot_just_txt}`




# Script

## Dependencies
- `yq`
- `<++>`
- `<++>`

## Execution
`generate.sh`
